package android.cs453.pdtapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.w3c.dom.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


public class DeviceActivity extends AppCompatActivity {

    Spinner companiesSpinner, locationSpinner, dataPathSpinner, timeZoneSpinner;
    EditText serviceURL, deviceID, deviceName;
    Button saveButton, backButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device);

        saveButton = (Button)findViewById(R.id.save_button);
        backButton = (Button)findViewById(R.id.back_button);
        serviceURL = (EditText)findViewById(R.id.service_url_edit_text);
        deviceID = (EditText)findViewById(R.id.device_id_edit_text);
        deviceName = (EditText)findViewById(R.id.device_name_edit_text);
        companiesSpinner = (Spinner)findViewById(R.id.companies_spinner);
        locationSpinner = (Spinner) findViewById(R.id.location_spinner);
        dataPathSpinner = (Spinner)findViewById(R.id.data_path_spinner);
        timeZoneSpinner = (Spinner)findViewById(R.id.time_zone_spinner);


        String root = Environment.getExternalStorageDirectory().toString();
        File file= new File(root+"/PDTApplication/Config.xml");
        if (file.exists())
        {
            InputStream is = null;
            try {
                is = new FileInputStream(root+"/PDTApplication/Config.xml");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
            try {
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(is);
                NodeList nList = doc.getElementsByTagName("DeviceManagement");
                for (int i = 0; i < nList.getLength(); i++) {
                    if (nList.item(0).getNodeType() == Node.ELEMENT_NODE) {
                        HashMap<String, String> user = new HashMap<>();
                        Element elm = (Element) nList.item(i);
                        serviceURL.setText(getNodeValue("ServiceURL",elm));
                        deviceID.setText(getNodeValue("DeviceID",elm));
                        deviceName.setText(getNodeValue("DeviceName", elm));
                        String[] companies = {getNodeValue("CompanyName", elm)};
                        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item,companies);
                        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        companiesSpinner.setAdapter(aa);

                        //lblCompany.setText(getNodeValue("CompanyName", elm));
                        //lblLocation.setText(getNodeValue("LocationName", elm));
                        //ipAddress.setText(getNodeValue("IPAddress", elm));
                    }
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

        //Service URL listener - when text is changed
        serviceURL.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //ignore
            }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //ignore
            }
            public void afterTextChanged(Editable s) {

                String SOAP_ACTION = "http://tempuri.org/GetData";
                String METHOD_NAME = "GetData";
                String NAMESPACE = "http://tempuri.org";
                String URL = "http://localhost:8081/Service.asmx";

                //Need to add values to str array below
                String[] str = new String[]{};
                List<String> companies = new ArrayList<>();

                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
                request.addProperty("Param", str);

                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                //Marshal arrayMarshal = new MarshallArray();
                //arrayMarshal.register(envelope);
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL, 0);
                try {
                    androidHttpTransport.call(SOAP_ACTION, envelope);
                    //SoapObject result = (SoapObject)envelope.bodyIn;
                    SoapPrimitive resultString = (SoapPrimitive) envelope.getResponse();

                    ResultSet rs = (ResultSet) resultString;
                    while (rs.next()) {
                        companies.add(rs.toString());
                    }

                    ArrayAdapter<String> aa = new ArrayAdapter<String>(DeviceActivity.this, android.R.layout.simple_spinner_dropdown_item, companies);
                    companiesSpinner.setAdapter(aa);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        //Companies Spinner listener - when an item is selected
        companiesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            //We use the web service to update the Location Spinner below
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String SOAP_ACTION = "http://tempuri.org/GetData";
                String METHOD_NAME = "GetData";
                String NAMESPACE = "http://tempuri.org";
                String URL = "http://localhost:8081/Service.asmx";

                //Need to add values to str array below
                String[] str = new String[]{};
                List<String> locations = new ArrayList<>();

                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
                request.addProperty("Param", str);

                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                //Marshal arrayMarshal = new MarshallArray();
                //arrayMarshal.register(envelope);
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL, 0);
                try {
                    androidHttpTransport.call(SOAP_ACTION, envelope);
                    //SoapObject result = (SoapObject)envelope.bodyIn;
                    SoapPrimitive resultString = (SoapPrimitive) envelope.getResponse();

                    ResultSet rs = (ResultSet) resultString;
                    while (rs.next()) {
                        locations.add(rs.toString());
                    }

                    ArrayAdapter<String> aa = new ArrayAdapter<String>(DeviceActivity.this, android.R.layout.simple_spinner_dropdown_item, locations);
                    locationSpinner.setAdapter(aa);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            public void onNothingSelected(AdapterView<?> adapterView) {
                //ignore
            }
            });

        /*
        //Loading values into time zone spinner (from DAL class)
        DAL d = new DAL();
        List<String> timeZones = d.getTimeZones();
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, timeZones);
        timeZoneSpinner.setAdapter(adapter1);
         */

        //String[] dataPaths = new String[]{};
        //ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, dataPaths);
        //dataPathSpinner.setAdapter(adapter2);


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeviceActivity.this.finish();
            }
        });
    }
    protected String getNodeValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag);
        Node node = nodeList.item(0);
        if(node!=null){
            if(node.hasChildNodes()){
                Node child = node.getFirstChild();
                while (child!=null){
                    if(child.getNodeType() == Node.TEXT_NODE){
                        return  child.getNodeValue();
                    }
                }
            }
        }
        return "";
    }

    //Check web service
    public String CheckWebservice(String urlstring)
    {
        String s = "";
        try
        {
            URL url = new URL(urlstring);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            int responseCode = connection.getResponseCode();
            if(responseCode == HttpURLConnection.HTTP_OK) {
                s = "Available";
            }
            else {
                s = "Unavailable";
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return s;
    }

}