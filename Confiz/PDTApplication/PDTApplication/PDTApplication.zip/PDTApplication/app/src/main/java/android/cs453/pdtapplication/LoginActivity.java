package android.cs453.pdtapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity {

    private Button cancelButton, loginButton;
    private EditText username, password;
    private String correctUsername = "";
    private String correctPassword = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        cancelButton = (Button)findViewById(R.id.cancel_button);
        loginButton = (Button)findViewById(R.id.login_button);
        username = (EditText)findViewById(R.id.username_edit_text);
        password = (EditText)findViewById(R.id.password_edit_text);

        //Login button listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals(correctUsername) &&
                        password.getText().toString().equals(correctPassword)) {
                    //Grant access to user
                    login();
                }
                else if(!username.getText().toString().equals(correctUsername)){
                    //incorrect username
                    Toast toast = Toast.makeText(LoginActivity.this, "User does not exist.", Toast.LENGTH_SHORT);
                    toast.show();
                }
                else if(!password.getText().toString().equals(correctPassword)) {
                    //incorrect password
                    Toast toast = Toast.makeText(LoginActivity.this, "Password is incorrect.", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

        //Cancel button listener
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void login() {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }
}