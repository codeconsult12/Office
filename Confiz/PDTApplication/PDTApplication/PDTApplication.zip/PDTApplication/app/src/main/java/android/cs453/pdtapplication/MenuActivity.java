package android.cs453.pdtapplication;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private ImageView priceChecker, print, store, count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity);

        priceChecker = (ImageView)findViewById(R.id.pricechecker_image_view);
        print = (ImageView)findViewById(R.id.print_image_view);
        store = (ImageView)findViewById(R.id.store_image_view);
        count = (ImageView)findViewById(R.id.count_image_view);



    }
}
